﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Identity.Client;
using Repaso.Context;
using Repaso.Models;

namespace Repaso.Repository
{
    public class AlumnoDAO
    {

        public RegistroAlumnoContext context = new RegistroAlumnoContext();


        /* public List<Alumno> SelectAll()
         {
             var alumno = context.Alumnos.ToList<Alumno>();
             return alumno;
         }*/

        public List<Alumno> SelectAll() => context.Alumnos.Select(x => x).ToList();

        public Alumno? GetById(int id)
        {
            var alumno = context.Alumnos.Where(x => x.Id == id).FirstOrDefault();
            return alumno == null ? null : alumno;

        }

        public bool insertarAlumno(Alumno alumno)
        {
            try
            {
                var alum = new Alumno
                {
                    Direccion = alumno.Direccion,
                    Nombre = alumno.Nombre,
                    Edad = alumno.Edad,
                    Email = alumno.Email,
                    Dni = alumno.Dni

                };
                context.Alumnos.Add(alum);
                context.SaveChanges();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return false;
        }



              
             public List<AlumnoProfesor> alumnoProfesor(string nombreProfesor) {

            var listado = from a in context.Alumnos
                          join m in context.Matriculas
                          on a.Id equals m.AlumnoId
                          join asig in context.Asignaturas
                          on m.AsignaturaId equals asig.Id
                          where asig.Profesor == nombreProfesor
                          select new AlumnoProfesor
                          {
                              Id = a.Id,
                              Dni = a.Dni,
                              Nombre = a.Nombre,
                              Edad = a.Edad,
                              Email = a.Email,
                              asignatura = asig.Nombre
                              
                          };
            return listado.ToList(); 


             }
        public Alumno DNIAlumno(Alumno alumno)
        {
            var alumnos = context.Alumnos.Where(x => x.Dni == alumno.Dni).FirstOrDefault();
            return alumnos == null ? null : alumnos;
        }
            

    } 
}

