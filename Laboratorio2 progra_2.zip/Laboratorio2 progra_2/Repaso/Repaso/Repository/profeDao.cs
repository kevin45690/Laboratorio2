﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repaso.Context;
using Repaso.Models;

namespace Repaso.Repository
{
    public class profeDao
    {
        public RegistroAlumnoContext context = new RegistroAlumnoContext();
        public Profesor login(string usuario, string password) {
            var prof = context.Profesors.Where(p => p.Usuario == usuario && p.Pass == password).FirstOrDefault();

            return prof;
               
        }
    }
}
