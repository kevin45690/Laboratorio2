﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repaso.Models;
using Repaso.Repository;

namespace WebApi.Controllers
{
    [Route("api/")]
    [ApiController]
    public class profesorController : ControllerBase
    {
        private profeDao _profesor = new profeDao();




        [HttpPost("Autentificacion")]
        public string login([FromBody] Profesor profesor) {
            var registro = _profesor.login(profesor.Usuario, profesor.Pass);
            if(registro != null)
            {
                return registro.Usuario;
            }
            return "Elemento no Guardado" ; 
        }
    }
}
