﻿using Repaso.Models;
using Repaso.Repository;

AlumnoDAO alumnoDAO = new AlumnoDAO();
var alumno = alumnoDAO.SelectAll();

foreach (var item in alumno)
{
    Console.WriteLine(item.Nombre);
}


Console.WriteLine("ñññññññññññññññññññññññññññññññññññññññññññññññññññññññññññ");
var selectById = alumnoDAO.GetById(2);
Console.WriteLine(selectById?.Nombre);

var nuevoAlumno = new Alumno
{
    Direccion = "El salvador",
    Nombre = "Ricardo jr",
    Edad = 34,
    Email = "alumno.Email",
    Dni = "2222"
};
var insert = alumnoDAO.insertarAlumno(nuevoAlumno);
Console.WriteLine("ñññññññññññññññññññññññññññññññññññññññññññññññññññññññññññ");


